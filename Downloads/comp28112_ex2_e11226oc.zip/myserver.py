"""

Network server skeleton.

This shows how you can create a server that listens on a given network socket, dealing
with incoming messages as and when they arrive. To start the server simply call its
start() method passing the IP address on which to listen (most likely 127.0.0.1) and 
the TCP port number (greater than 1024). The Server class should be subclassed here, 
implementing some or all of the following five events. 

  onStart(self)
      This is called when the server starts - i.e. shortly after the start() method is
      executed. Any server-wide variables should be created here.
      
  onStop(self)
      This is called just before the server stops, allowing you to clean up any server-
      wide variables you may still have set.
      
  onConnect(self, socket)
      This is called when a client starts a new connection with the server, with that
      connection's socket being provided as a parameter. You may store connection-
      specific variables directly in this socket object. You can do this as follows:
          socket.myNewVariableName = myNewVariableValue      
      e.g. to remember the time a specific connection was made you can store it thus:
          socket.connectionTime = time.time()
      Such connection-specific variables are then available in the following two
      events.

  onMessage(self, socket, message)
      This is called when a client sends a new-line delimited message to the server.
      The message paramater DOES NOT include the new-line character.

  onDisconnect(self, socket)
      This is called when a client's connection is terminated. As with onConnect(),
      the connection's socket is provided as a parameter. This is called regardless of
      who closed the connection.

Now it’s your turn to write some code. Your first task is to create a server (call it myserver.py)
that simply acknowledges that a client has connected, that it has received a message, and that
a client has disconnected. All you need to do here is print out a suitable message on the screen
(server terminal window) for each event. You should be able to test all of these eventualities using
telnet, as we did for EchoServer and EgoServer.
Hint: your server is going to be very similar to our EchoServer implementation but with a few
more methods implemented (and these methods are explained in a lot of detail at the top of the file!)

"""
import sys
from ex2utils import Server

class OllieServer(Server):

    users = {}
    sockets = {}
    clients = 0

    def __init__(self):
        super().__init__()
        self.clients = 0

    def onStart(self):
        print("Ollie server has started")

    def onMessage(self, socket, message):
        print("Ollie server has received a message")
        (command, sep, parameter) = message.strip().partition(' ')
        if (command == "register"):
            if parameter in self.users.values():
                reply = 'Sorry this name has already taken, please try again'
                socket.send(reply.encode())
            else:
                socket.username = parameter
                self.users[socket] = parameter
                self.sockets[parameter] = socket
                reply = 'Registered as ' + parameter
                socket.send(reply.encode())
        elif (command == "broadcast"):
            if socket in self.users:
                for user_socket in self.users:
                    if user_socket != socket:
                        user_socket.send((socket.username + ': ' + parameter).encode())
                reply = 'Broadcast sent'
                socket.send(reply.encode())
            else:
                reply = 'Error: Not Registered'
                socket.send(reply.encode())
        elif (command == "message"):
            (recipient, sep, message) = parameter.partition(' ')
            if recipient in self.sockets:
                msg = (socket.username +": "+message)
                self.sockets[recipient].send(msg.encode())
                reply = 'Message sent to ' + recipient
                socket.send(reply.encode())
            else:
                reply = 'Error: User not found'
                socket.send(reply.encode())
        elif (command == 'userlist'):
            reply = 'Connected Users:\n' + '\n'.join(sorted(self.users.values()))
            socket.send(reply.encode())
        elif (command == "quit"):
            socket.send("Ollie server has stopped".encode())
            if socket in self.users:
                del self.sockets[self.users[socket]]
                del self.users[socket]
        else:
            socket.send('Error: Invalid Command'.encode())
        return True
    
    def onStop(self):
        print("Ollie server has stopped")

    def onConnect(self, socket):
        print("Ollie server has connected")
        self.clients += 1
        socket.username = ""
        print("There are " + str(self.clients) + " connected to the server")
        socket.send("Please use the following commands:\n register 'Name' - sets your name on the server\n message 'Recipient' 'YourMessage' - sends a message to the specified user\n broadcast 'YourMessage' - send a message to all users\n userlist - lets you see all users connected to the server".encode())

    def onDisconnect(self, socket):
        print("Ollie server has disconnected")
        self.clients -= 1
        print("There are " + str(self.clients) + " connected to the server")

# Parse the IP address and port you wish to listen on.
ip = sys.argv[1]
port = int(sys.argv[2])

# Create an Ollie server.
server = OllieServer()

# Start server
server.start(ip, port)

