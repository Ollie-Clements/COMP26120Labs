"""

Network Client Skeleton:

Once the server has been started using: python3 myserver.py [ip] [port] 
The client can then be started using: python3 myclient.py [ip] [port] 

Both the ip and port need to be the same when running myserver.py and myclient.py.
I recommend using localhost as the ip and 8090 as the port, but other options are available.

Once both the server and client/clients are up and running we can start to actually use the code.
It's important that the first command run is the register command so that each client is instantly able to be identified by name
The following commands are available for clients to use:

	register [username]: Used to set a name on the server for a client, if the name is already taken then the client will be prompted to try again until an unique name is selected.
	message [receiver] [content]: Used to send a message to the intended client. Receiver is the name of the client you want to send the message to and content is the actual message you would like to send.
	broadcast [content]; Used to send a message to all other clients connected to the server. Content is the actual message you would like to send.
	userlist: Used to see the names of other clients connected to the server. Returns a list of the names of connected clients to the client who requested it
	quit: Used for a client to disconnect from the server.

"""
import sys
from ex2utils import Client
import time

class IRCClient(Client):

	def __init__(self):
		super().__init__()
		self.connected = False
		self.username = None

	# def onConnect(self, socket):
	# 	self.registerUsername()

	def sendMessage(self):
		response = input()
		client.send(response.encode())
		#self.send(response.encode())

	def onMessage(self, socket, message):
		if (message == "Ollie server has stopped"):
			client.stop()
			#self.stop()
			#global connected
			self.connected = True
		else:
			print(message)
		return True

	# def registerUsername(self):
	# 	while True:
	# 		self.username = input("Please enter a screen name: ")
	# 		message = f"register {self.username}"
	# 		self.send(message.encode())
	# 		time.sleep(0.1)
	# 		if self.username in self.responses:
	# 			print(self.responses[self.username].decode())
	# 			break
	# 		else:
	# 			print("Sorry but that screen name is already taken, please try again")


# Parse the IP address and port you wish to connect to.
ip = sys.argv[1]
port = int(sys.argv[2])

# Create an IRC client.
client = IRCClient()

# Start the server
client.start(ip, port)
#print("Please use the following commands:\n register 'Name' - sets your name on the server\n message 'Recipient' 'YourMessage' - sends a message to the specified user\n broadcast 'YourMessage' - send a message to all users\n userlist - lets you see all users connected to the server\n quit - ends your connection with the server")
while client.connected == False:
	client.sendMessage()

